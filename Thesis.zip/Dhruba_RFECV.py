import pandas as pd
import matplotlib.pyplot as plt
#import matplotlib
#matplotlib.use("agg")
#import matplotlib.pyplot as plt
data = pd.read_csv("Loan.csv")

##########################################
#DROPPING NULL and DUPLICATE VALUES 
data.dropna(inplace=True)
data = data.drop_duplicates(keep = "first")
##########################################


##################################################
#Handling categorical values
data = pd.get_dummies(data, columns = ['home_ownership', 'verification_status', 'purpose', 'addr_state'])

from sklearn.preprocessing import LabelEncoder
labelencoder = LabelEncoder()
data['loan_status'] = labelencoder.fit_transform(data['loan_status'])

#################################################

##############################################

#splitting into dependent and independent variables
X = data.loc[:, data.columns != 'loan_status'].values
Y = data.loc[:, data.columns == 'loan_status'].values
Y = Y.ravel()
##############################################

##Applying RFECV
print("running feature selection")
from sklearn.feature_selection import RFECV
from sklearn.ensemble import RandomForestClassifier
classifier = RandomForestClassifier(random_state=0, random_state=0, max_depth = 20 , max_features = 1, min_samples_split = 3, bootstrap = 'True', n_estimators = 100)
rfecv = RFECV(estimator=classifier, step=1, cv=5, scoring='accuracy')
rfecv = rfecv.fit(X, Y)
print('Optimal number of features :', rfecv.n_features_)
print('Best features :')
print(rfecv.support_)
print("Feature ranking")
print(rfecv.ranking_)
print("selection done")
X_new = rfecv.transform(X)

#######################################
#Test And Train Split
from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X_new, Y, test_size=0.3, random_state=0)
print(y_train.mean())
##########################################

##########################################
#Applying smote for imbalanced datasets
from imblearn.over_sampling import SMOTE
smt = SMOTE()
X_train, y_train = smt.fit_sample(X_train, y_train)
print(y_train.mean())
#######################################

##########################################
#Feature Scaling using Standardization AND VARIANCE CALCULATION
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
###########################################

#########################################

#RANDOM FOREST CLASSIFIER
print("Running R Forest")
classifier.fit(X_train,y_train)
#print(classifier.feature_importances_)
predict = classifier.predict(X_test)
print(predict)
print("Score with pure test set")
print(classifier.score(X_test,y_test))

###########################################

############################################
#K folds cross validation on test set only
from sklearn.model_selection import cross_val_score
accuracy = cross_val_score(estimator = classifier, X = X_train, y = y_train, cv=5)
print("cross val score with smote test set")
print(accuracy.mean())
print("cross val variance")
print(accuracy.std())
############################################


###########################################
#Confusion matrix
from sklearn import metrics
from sklearn.metrics import f1_score
conf_mat = metrics.confusion_matrix(y_test,predict)
TN = conf_mat[1,1]
TP = conf_mat[0,0]
FN = conf_mat[1,0]
FP = conf_mat[0,1]

print("True positive UGS : " + str(TP))
print("True negative UGS: " + str(TN))
print("False positive UGS : " + str(FP))
print("False negative  UGS : " + str(FN))

print("f1 score")
print(f1_score(y_test, predict))
########################################

########################################
#Recall and precision
print("Recall score UGS : ")
print(metrics.recall_score(y_test, predict))
print("Precision score UGS : ")
print(metrics.precision_score(y_test, predict))
########################################

#############################################

# calculate the fpr and tpr for all thresholds of the classification
probs = classifier.predict_proba(X_test)
preds = probs[:,1]
fpr, tpr, threshold = metrics.roc_curve(y_test, preds)
roc_auc = metrics.auc(fpr, tpr)
print("AUC score UGS : ")
print(metrics.roc_auc_score(y_test, preds))

plt.title('Receiver Operating Characteristic')
plt.plot(fpr, tpr, 'b', label = 'AUC = %0.2f' % roc_auc)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.show()

from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, predict)
####################################################