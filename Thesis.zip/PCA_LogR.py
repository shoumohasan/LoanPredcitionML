import pandas as pd
data = pd.read_csv("Loan.csv")

##########################################
#DROPPING NULL and DUPLICATE VALUES 
data.dropna(inplace=True)
data = data.drop_duplicates(keep = "first")
##########################################

##################################################
#Handling categorical values
data = pd.get_dummies(data, columns = ['home_ownership', 'verification_status', 'purpose', 'addr_state'])

from sklearn.preprocessing import LabelEncoder
labelencoder = LabelEncoder()
data['loan_status'] = labelencoder.fit_transform(data['loan_status'])

##########################################

##########################################

#splitting into dependent and independent variables
X = data.loc[:, data.columns != 'loan_status'].values
Y = data.loc[:, data.columns == 'loan_status'].values
Y = Y.ravel()
##########################################

#######################################
#Test And Train Split

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, Y, test_size=0.3, random_state=0)
print(y_train.mean())
##########################################

##########################################
#Applying smote for imbalanced datasets
from imblearn.over_sampling import SMOTE
smt = SMOTE()
X_train, y_train = smt.fit_sample(X_train, y_train)
print(y_train.mean())
#######################################

##########################################
#Feature Scaling using Standardization AND VARIANCE CALCULATION
from sklearn.preprocessing import StandardScaler
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)
###########################################

#######################################
#PCA IMPLEMENTATION
from sklearn.decomposition import PCA
pca = PCA(n_components= 70)
X_train = pca.fit_transform(X_train)
X_test = pca.transform(X_test)
var = pca.explained_variance_ratio_
######################################

###########################################
#LogR Classifier
print("Running LogR")
from sklearn.linear_model import LogisticRegression
classifier = LogisticRegression(random_state = 0)
classifier.fit(X_train,y_train)
predict = classifier.predict(X_test)
print(predict)
print("Score with pure test set")
print(classifier.score(X_test,y_test))
##########################################

############################################
##K folds cross validation on test set only
#from sklearn.model_selection import cross_val_score
#accuracy = cross_val_score(estimator = classifier, X = X_train, y = y_train, cv=10)
#print("cross val score with smote test set")
#print(accuracy.mean())
############################################

###########################################
#APPLYING GRIDSEARCH WITH K FOLDS CROSS VALIDATION
from sklearn.model_selection import GridSearchCV
para = { "penalty":["l1","l2"],
        'C': [0.0001, 0.001, 1, 100, 1000]}
 
grid_search = GridSearchCV(estimator = classifier, param_grid = para, scoring = 'accuracy', cv=5, n_jobs = -1)  
grid_search = grid_search.fit(X_train, y_train)      
new_accuracy = grid_search.best_score_
new_para =  grid_search.best_params_
print("Grid search score")
print(grid_search.best_score_)
print("best parameters")
print(grid_search.best_params_)
##########################################

###########################################
#Confusion matrix
from sklearn import metrics
conf_mat = metrics.confusion_matrix(y_test,predict)
TN = conf_mat[1,1]
TP = conf_mat[0,0]
FN = conf_mat[1,0]
FP = conf_mat[0,1]

print("True positive WGS : " + str(TP))
print("True negative WGS: " + str(TN))
print("False positive WGS : " + str(FP))
print("False negative  WGS : " + str(FN))

########################################

########################################
#Recall and precision
print("Recall score WGS : ")
print(metrics.recall_score(y_test, predict))
print("Precision score WGS : ")
print(metrics.precision_score(y_test, predict))
########################################

#############################################
#Getting AUC and ploting ROC
# calculate the fpr and tpr for all thresholds of the classification
probs = classifier.predict_proba(X_test)
preds = probs[:,1]
fpr, tpr, threshold = metrics.roc_curve(y_test, preds)
roc_auc = metrics.auc(fpr, tpr)
print("AUC score WGS : ")
print(metrics.roc_auc_score(y_test, preds))

# method I: plt
import matplotlib.pyplot as plt
plt.title('Receiver Operating Characteristic')
plt.plot(fpr, tpr, 'b', label = 'AUC = %0.2f' % roc_auc)
plt.legend(loc = 'lower right')
plt.plot([0, 1], [0, 1],'r--')
plt.xlim([0, 1])
plt.ylim([0, 1])
plt.ylabel('True Positive Rate')
plt.xlabel('False Positive Rate')
plt.show()

####################################################

